import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(("localhost", 8000))
server_socket.listen(10)

while True:
    client_socket, addr = server_socket.accept()
    data = client_socket.recv(1024)
    if data != b"":
        print(data.decode("utf-8"))

    # Remember to close the client socket when you're done with it
    client_socket.close()
