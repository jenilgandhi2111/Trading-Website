class Message:
    def __init__(self,messageType,metaData = None):
        self.sender = "StockServerDemo"
        self.messageType = messageType
        self.metaData = metaData    
        self.message = {"messageType": messageType, "sender": self.sender, "meta": metaData}

    def serializeMessage(self):
        return  str(self.message)

class DataMessage(Message):
    def __init__(self, metaData=None):
        super().__init__("DataMessage", {"data":metaData})
    
    
