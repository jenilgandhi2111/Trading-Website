import os
import sys
import json
from Message import DataMessage
class DataLoader:
    def readConfig(self):
        with open(os.path.join(os.getcwd(),"Config","config.json"),"r") as file:
            data = json.loads(file.read())
        return data
    def __init__(self):
        self.ln = 0
        self.configFile = self.readConfig()
        self.symbols = self.configFile.keys()
        self.prices = {}
        for sym in self.symbols:
            self.prices[sym] = {"seekPtr":43}
        
    
    def getStockDataFromSymbol(self,symbol,ptr):
        fptr = open(os.path.join("Data",symbol+".csv"),"r")
        fptr.seek(ptr)
        data = fptr.readline().split(",")
        obj = {
            "symbol":symbol,
            "price":data[1],
            "volume":data[-1]
        }
        nextPtr = fptr.tell()
        fptr.close()
        return [obj,nextPtr]
    
    def getNextMessage(self):
        retObj = []
        for sym in self.symbols:
            [obj,nextPtr] = self.getStockDataFromSymbol(sym,self.prices[sym]["seekPtr"])
            self.prices["seekPtr"] = nextPtr
            retObj.append(obj)
        
        
        return DataMessage(retObj)