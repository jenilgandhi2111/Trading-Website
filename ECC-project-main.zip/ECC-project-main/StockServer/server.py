import socket
import os
import time
from DataLoader import DataLoader
import json
from Message import Message
from Message import DataMessage

class Server:
    def readConfig(self):
        with open(os.path.join(os.getcwd(),"Config","serverConfig.json")) as file:
            data = json.loads(file.read())
        return data
    def __init__(self) -> None:
        self.configData = self.readConfig()
        self.port = self.configData["port"]
        self.host = self.configData["host"]
        self.dataLoader = DataLoader()

    def sendMessage(self,message:Message):
        # try:
        print(message.serializeMessage())
        print(self.port,self.host)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect(("localhost", 8000))

        sock.sendall(bytes(message.serializeMessage(),"utf-8"))
        sock.close()
        # except Exception as E:
        #     print(str(E))


    def run(self):
        while True:
            self.sendMessage(self.dataLoader.getNextMessage())
            time.sleep(1)


server = Server()
server.run()

    