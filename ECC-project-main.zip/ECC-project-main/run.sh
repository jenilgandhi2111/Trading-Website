# Would run the stock market server first and then would start the application
